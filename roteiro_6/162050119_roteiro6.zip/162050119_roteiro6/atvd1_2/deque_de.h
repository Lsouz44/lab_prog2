#ifndef DEQUE_DE_H
#define DEQUE_DE_H

typedef struct NO{
    int info;
    struct NO* prox;
    struct NO* ant;
}NO;

typedef struct{
    int qtd;
    struct NO* ini;
    struct NO* fim;
}Deque;

Deque* criaDeque();
NO* alocarNO();
void liberarNO(NO* no);
int tamanhoDeque(Deque *dq);
int estaVazio(Deque *dq);
int insereFim(Deque* dq, int elem);
int insereIni(Deque* dq, int elem);
int removeFim(Deque* dq);
int removeIni(Deque* dq);
int verIni(Deque* dq, int* p);
int verFim(Deque* dq, int* p);
void imprime(Deque* dq);
void destroiDeque(Deque *dq);

#endif