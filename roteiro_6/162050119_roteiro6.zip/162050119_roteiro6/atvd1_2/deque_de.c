#include <stdio.h>
#include <stdlib.h>
#include "deque_de.h"

Deque* criaDeque(){
    Deque* dq;
    dq = (Deque*) malloc (sizeof(Deque));
    if(dq != NULL){
        dq->qtd = 0;
        dq->ini = dq->fim = NULL;
    }
    return dq;
}


NO* alocarNO(){
    NO* novo = (NO*)malloc(sizeof(NO));
    if(novo != NULL){
        novo->info = 0;
        novo->prox = NULL;
        novo->ant = NULL;
    }
    return novo;
}

void liberarNO(NO* no){
    if(no != NULL){
        free(no);
    }
}


int tamanhoDeque(Deque *dq){
    if(dq == NULL) return -1;
    return dq->qtd;
}

int estaVazio(Deque *dq){
    if(dq == NULL) return -1;
    return (dq->qtd == 0);
}

int insereFim(Deque* dq, int elem){
    if(dq == NULL) return 0;
    NO* novo = alocarNO();
    if(novo == NULL) return 0;
    novo->info = elem;
    novo->prox = NULL;
    if(estaVazio(dq)){
        novo->ant = NULL;
        dq->ini = novo;
    }else{
        dq->fim->prox = novo;
        novo->ant = dq->fim;
    }
    dq->fim = novo;
    dq->qtd++;
    return 1;
}

int insereIni(Deque* dq, int elem){
    if(dq == NULL) return 0;
    NO* novo = alocarNO();
    if(novo == NULL) return 0;
    novo->info = elem;
    novo->ant = NULL;
    if(estaVazio(dq)){
        novo->prox = NULL;
        dq->fim = novo;
    }else{
        dq->ini->ant = novo;
        novo->prox = dq->ini;
    }
    dq->ini = novo;
    dq->qtd ++;
    return 1;
}

int removeFim(Deque* dq){
    if(dq == NULL) return 0;
    if(estaVazio(dq)) return 0;
    NO* aux = dq->fim;
    if(dq->ini == dq->fim){
        dq->ini = dq->fim = NULL;
    }else{
        dq->fim = dq->fim->ant;
        dq->fim->prox = NULL;
    }
    liberarNO(aux);
    dq->qtd--;
    return 1;
}

int removeIni(Deque* dq){
    if(dq == NULL) return 0;
    if(estaVazio(dq)) return 0;
    NO* aux = dq->ini;
    if(dq->ini == dq->fim){
        dq->ini = dq->fim = NULL;
    }else{
        dq->ini = dq->ini->prox;
        dq->ini->ant = NULL;
    }
    liberarNO(aux);
    dq->qtd--;
    return 1;
}

int verIni(Deque* dq, int* p){
    if(dq == NULL) return 0;
    if(estaVazio(dq)) return 0;
    *p = dq->ini->info;
    return 1;
}

int verFim(Deque* dq, int* p){
    if(dq == NULL) return 0;
    if(estaVazio(dq)) return 0;
    *p = dq->fim->info;
    return 1;
}

void imprime(Deque* dq){
    if(dq == NULL) return ;
    if(estaVazio(dq)){
        printf("Deque Vazio!\n");
        return;
    }
    NO* aux = dq->ini ;
    printf("Elementos:\n");
    while(aux != NULL){
        printf("%d ", aux->info);
        aux = aux->prox;
    }
    printf("\n");
}

void destroiDeque(Deque *dq){
    if(dq != NULL){
        NO* aux;
        while(dq->ini != NULL){
            aux = dq->ini;
            dq->ini = dq->ini->prox;
            liberarNO(aux);
        }
        free(dq);
    }
}