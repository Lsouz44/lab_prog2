#ifndef FPHEAP_H
#define FPHEAP_H

#define MAX 100

typedef struct NO{
    int info, prio;
}NO;

typedef struct{
    int qtd;
    NO dados[MAX];
}FilaP;

FilaP* criaFila();
void destroiFila(FilaP* fp);
int tamanhoFila(FilaP *fp);
int estaCheia(FilaP *fp);
int estaVazia(FilaP *fp);
void imprime(FilaP* fp);
void trocaNO(NO* a, NO* b);
int inserirPrio(FilaP* fp, int elem, int pri);
void ajustaHeapInsere(FilaP* fp, int filho);
int verIni(FilaP* fp, int* valor, int* pri);
int removeIni(FilaP* fp);
void ajustaHeapRemove(FilaP* fp, int pai);

#endif