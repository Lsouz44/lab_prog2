#include <stdio.h>
#include <stdlib.h>
#include "fpse.h"

int main() {
    FilaP* fp = NULL;
    int opcao, elemento, prioridade;

    do {
        printf("\nMenu:\n");
        printf("1 - Criar Fila\n");
        printf("2 - Inserir um item pela prioridade\n");
        printf("3 - Ver o inicio da Fila\n");
        printf("4 - Remover um item\n");
        printf("5 - Imprimir a Fila\n");
        printf("6 - Mostrar o tamanho da Fila\n");
        printf("7 - Destruir a Fila\n");
        printf("8 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                if(fp == NULL){
                    fp = criaFila();
                    printf("Fila criada com sucesso!\n");
                }else{
                    printf("Fila ja foi criada!\n");
                }
                break;
            case 2:
                if(fp != NULL){
                    printf("Digite o elemento a ser inserido: ");
                    scanf("%d", &elemento);
                    printf("Digite a prioridade do elemento: ");
                    scanf("%d", &prioridade);
                    if(inserirPrio(fp, elemento, prioridade)){
                        printf("Elemento inserido na fila com sucesso!\n");
                    }else{
                        printf("Falha ao inserir elemento na fila.\n");
                    }
                }else{
                    printf("Fila nao foi criada!\n");
                }
                break;
            case 3:
                if(fp != NULL){
                    if(verIni(fp, &elemento)){
                        printf("Elemento no inicio da fila: %d\n", elemento);
                    }else{
                        printf("Fila esta vazia.\n");
                    }
                }else{
                    printf("Fila nao foi criada!\n");
                }
                break;
            case 4:
                if(fp != NULL){
                    if(removeIni(fp)){
                        printf("Elemento removido da fila com sucesso!\n");
                    }else{
                        printf("Falha ao remover elemento da fila.\n");
                    }
                }else{
                    printf("Fila nao foi criada!\n");
                }
                break;
            case 5:
                if(fp != NULL){
                    imprime(fp);
                }else{
                    printf("Fila nao foi criada!\n");
                }
                break;
            case 6:
                if(fp != NULL){
                    int tamanhoFila = tamanho(fp);
                    printf("Tamanho da fila: %d\n", tamanhoFila);
                }else{
                    printf("Fila nao foi criada!\n");
                }
                break;
            case 7:
                if(fp != NULL){
                    destroiFila(fp);
                    fp = NULL;
                    printf("Fila destruida com sucesso!\n");
                }else{
                    printf("Fila nao foi criada!\n");
                }
                break;
            case 8:
                if(fp != NULL){
                    destroiFila(fp);
                }
                printf("Saindo...\n");
                break;
            default:
                printf("Opção invalida! Tente novamente.\n");
        }

    }while(opcao != 8);

    return 0;
}