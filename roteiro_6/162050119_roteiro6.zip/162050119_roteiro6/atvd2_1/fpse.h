#ifndef FPSE_H
#define FPSE_H

typedef struct NO{
    int info, prio;
    struct NO* prox;
}NO;

typedef struct NO* FilaP;

FilaP* criaFila();
NO* alocarNO(int elem, int pri);
void liberarNO(NO* no);
int estaVazia(FilaP *fp);
int tamanho(FilaP *fp);
int inserirPrio(FilaP* fp, int elem, int pri);
int removeIni(FilaP* fp);
int verIni(FilaP* fp, int* p);
void imprime(FilaP* fp);
void destroiFila(FilaP* fp);

#endif